#!/bin/bash

## Global Variables ##
DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" >/dev/null 2>&1 && pwd )"
PORTSHIFT_BUNDLE_FILENAME="$DIR""/securecn_bundle.yml"
CHECK_OPENSSL="FALSE"

K8SCLI_CMD="kubectl"

print_usage() {
  printf "
  Usage: install_bundle.sh [OPTION]...

  Panoptica installer.

      --uninstall                   Uninstall Panoptica bundle.
      --skip-ready-check            Don't wait for Panoptica controller to be ready.
      --kubeconfig                  Path to the kubeconfig file to use for CLI requests.
      --override-tracing-certs      When set, the installer will override tracing tls k8s secrets and configmap.
      --skip-tracing-certs-creation When set, the installer will skip the creation of tracing tls k8s secrets and configmap.
 "
}

CHECK_OPENSSL="TRUE"

if [[ "${CHECK_OPENSSL}" == "TRUE" ]] ; then
    VERSION=$(openssl version)
    if (echo $VERSION | grep -q -i libressl); then
        echo "The installed 'openssl' command is using LibreSSl: ${VERSION}"
        echo "Please install the official OpenSSL"
        echo "On OSX you can install with brew: 'brew install openssl'"
        echo "and follow the 'brew' recommendations to replace 'openssl' command"
        exit 1
    fi
fi


## Common Code ##
# Creates a new file with the content of the given file from start line to end line.
# $1: start line
# $2: end line
# $3: input file
# $4: output file
# If the start line is empty, it will copy from the beginning. If the end line is empty, it will end at the end of file.
function extract_file() {
  local TO_START="$1"
  local TO_END="$2"
  local INPUT="$3"
  local OUTPUT="$4"

  while IFS= read -r line
  do
      if [[ -z $START ]] && [[ "$TO_START" == "" ]] ; then
      echo -n > "$OUTPUT"
      echo "$line" >> "$OUTPUT"
      local START="TRUE"
    elif [[ -z $START ]] && [[ "$line" == "$TO_START" ]] ; then
      echo -n > "$OUTPUT"
      local START="TRUE"
    elif [[ ! -z $START ]] && [[ "$TO_END" == "" || "$line" != "$TO_END" ]] ; then
      echo "$line" >> "$OUTPUT"
    elif [[ ! -z $START ]] && [[ "$line" == "$TO_END" ]] ; then
      break
    fi
  done < "$INPUT"
}

function install_istio_crds() {
  local RESPONSE

  # ISTIO CRDS (Custom Resources)
  local CRDS=(
  authorizationpolicies.security.istio.io
  destinationrules.networking.istio.io
  envoyfilters.networking.istio.io
  gateways.networking.istio.io
  istiooperators.install.istio.io
  peerauthentications.security.istio.io
  proxyconfigs.networking.istio.io
  requestauthentications.security.istio.io
  serviceentries.networking.istio.io
  sidecars.networking.istio.io
  telemetries.telemetry.istio.io
  virtualservices.networking.istio.io
  wasmplugins.extensions.istio.io
  workloadentries.networking.istio.io
  workloadgroups.networking.istio.io
  )

  local ISTIO_CRDS_FILENAME="$DIR""/istio_init_bundle_ag.yml"

  extract_file "######################################## ISTIO #######################################################" "####### DONE ISTIO INIT PART  ########" "${PORTSHIFT_BUNDLE_FILENAME}" "$ISTIO_CRDS_FILENAME"

  echo "Installing istio custom resources"
  RESPONSE=$(${K8SCLI_CMD} apply -f "${ISTIO_CRDS_FILENAME}")
  if [[ $? -ne 0 ]]
  then
    echo "Failed to install istio crds: $RESPONSE"
    rm "${ISTIO_CRDS_FILENAME}"
    exit 1
  fi

  for crd in "${CRDS[@]}"
  do
    local TIMER=0
    # get custom resource
    RESPONSE=$(${K8SCLI_CMD} get crds "${crd}" 2>&1)
    # check last exit code
    while [[ $? -ne 0 ]]
    do
  	echo "Waiting for custom resource definitions to be ready: ${crd} "
      sleep 1
      TIMER=$((TIMER + 1))

      ## timeout of 60 seconds
      if [[ TIMER -eq 60 ]]
      then
  	  echo "Could not get custom resource: ${crd}: "
        echo "${RESPONSE} "
        exit 1
      fi
      RESPONSE=$(${K8SCLI_CMD} get crds ${crd} 2>&1)
    done
  done


  echo "Finished creating istio custom resources"
  echo ""
  rm "${ISTIO_CRDS_FILENAME}"
}

function install_istio() {
  local RESPONSE

  local ISTIO_FILENAME="$DIR""/istio_bundle_ag.yml"


  extract_file "####### DONE ISTIO INIT PART  ########" "######################################## PORTSHIFT #######################################################" "${PORTSHIFT_BUNDLE_FILENAME}" "$ISTIO_FILENAME"

  echo "Installing istio components"
  RESPONSE=$(${K8SCLI_CMD} apply -f "${ISTIO_FILENAME}" 2>&1)
  if [[ $? -ne 0 ]]
  then
    echo "Failed to install istio: $RESPONSE"
    rm "${ISTIO_FILENAME}"
    exit 1
  fi
  echo "Finished installing istio"
  rm "${ISTIO_FILENAME}"
}

in_subnet() {
    # Determine whether IP address is in the specified subnet.
    #
    # Args:
    #   cidr_subnet: Subnet, in CIDR notation.
    #   ip_addr: IP address to check.
    #
    # Returns:
    #   0|1
    #
    local readonly cidr_subnet="${1}"
    local readonly ip_addr="${2}"
    local subnet_ip cidr_mask netmask ip_addr_subnet subnet rval

    subnet_ip=$(echo "${cidr_subnet}" | cut -d'/' -f1)
    cidr_mask=$(echo "${cidr_subnet}" | cut -d'/' -f2)

    netmask=$(( 0xFFFFFFFF << $(( 32 - ${cidr_mask} )) ))

    # Apply netmask to both the subnet IP and the given IP address
    ip_addr_subnet=$(( netmask & $(ip_to_int ${ip_addr}) ))
    subnet=$(( netmask & $(ip_to_int ${subnet_ip}) ))

    # Subnet IPs will match if given IP address is in CIDR subnet
    [ "${ip_addr_subnet}" == "${subnet}" ] && rval=0 || rval=1

    return $rval
}

ip_to_int() {
    local readonly ip_addr="${1}"
    local ip_1 ip_2 ip_3 ip_4

    ip_1=$(echo "${ip_addr}" | cut -d'.' -f1)
    ip_2=$(echo "${ip_addr}" | cut -d'.' -f2)
    ip_3=$(echo "${ip_addr}" | cut -d'.' -f3)
    ip_4=$(echo "${ip_addr}" | cut -d'.' -f4)

    echo $(( ip_1 * 256**3 + ip_2 * 256**2 + ip_3 * 256 + ip_4 ))
}

# Validate that if ip-masq-agent is enabled on the cluster, that the POD CIDR is either:
# - within one of the user configured nonMasqueradeCIDRs
# OR
# - in one of the default nonMasqueradeCIDRs
validate_ip_masq_agent_config() {
    # See if the ip-masq-agent daemonset is installed
    kubectl get daemonsets/ip-masq-agent -n kube-system 2> /dev/null > /dev/null
    if [[ $? -ne 0 ]]; then
        # ip-masq-agent not found no need to continue
        return
    fi
    # Try to get the ip-masq-agent config map
    ipMasqConfig=$(kubectl get configmaps/ip-masq-agent -n kube-system -o jsonpath='{.data.config}' 2> /dev/null)
    if [[ $? -ne 0 ]]; then
        # No IP masq config; use default IP ranges
        # TODO(sambetts) Probably need to change these defaults depending on
        # the provider (GKE vs Amazon etc). The defaults here are the GKE ones:
        # https://cloud.google.com/kubernetes-engine/docs/concepts/ip-masquerade-agent#default-non-masq-dests
        masqSubnets="10.0.0.0/8 172.16.0.0/12 192.168.0.0/16 100.64.0.0/10 192.0.0.0/24 192.0.2.0/24 192.88.99.0/24 198.18.0.0/15 198.51.100.0/24 203.0.113.0/24 240.0.0.0/4"
    else
        # IP Masq config available
        # Parse ip-masq-config yaml into a list of IP addresses. For now the
        # logic is very dumb, find every line in the config with an IP address
        # (by matching a number followed by a dot) then print them separated by
        # spaces.
        masqSubnets="$(echo "${ipMasqConfig}" | awk '/[0-9]{1,3}\./{print $2}' ORS=' ')"
    fi

    # Get all Pod CIDRs from all the nodes
    podCIDRs="$(kubectl get nodes -o jsonpath='{.items[*].spec.podCIDRs[]}')"
    if [[ $? -ne 0 ]]; then
        echo "Failed to get podCIDRs from nodes, unable to validate ip-masq-agent configuration."
        exit 1
    fi

    # For each of the Pod CIDRs check their start IP is in at least one of the
    # nonMasqSubnets, otherwise inter-pod IPs required by panoptica to check
    # connections may be masked by the ip-masq-agent. If we find a Pod CIDR
    # which doesn't fit any of the subnets, then warn the user to check their
    # ip-masq configuration.
    for podCIDR in $podCIDRs; do
        podIp="$(echo "$podCIDR" | cut -d'/' -f1)"
        ok=0
        for ipMasqSubnet in $masqSubnets; do
            if in_subnet $ipMasqSubnet $podIp; then
                ok=1
                break
            fi
        done
        if [[ $ok -ne 1 ]]; then
            echo "WARNING! Found Node PodCIDR ${podCIDR} which may be subject to IP masking by ip-masq-agent. Ensure that your cluster's Pod Network CIDR is configured as a nonMasqueradeCIDR in ip-masq-agent's configuration otherwise Panoptica connection enforcement may not operate correctly."
        fi
    done
}


TRACING_CERT_DIR='tracing_certs/'

generate_tracing_certs(){
  ERR=$("$DIR"/certs_gen_tracing.sh -c ${TRACING_CERT_DIR})
  if [[ $? -ne 0 ]]
  then
    echo "failed to generate certificates for tracing"
    echo ${ERR}
    exit 1
  fi
  echo "certificates successfully generated for tracing"
}

# $1 - server name
# $2 - server namespace
create_server_tls_secret(){
  if [[ ! -z $OVERRIDE_TRACING_CERTS ]] ; then
    ${K8SCLI_CMD} delete secret $1-tls -n $2 --ignore-not-found
  fi

  ERR=$(${K8SCLI_CMD} create secret generic $1-tls -n $2 \
  --from-file=${TRACING_CERT_DIR}/$1/server.key \
  --from-file=${TRACING_CERT_DIR}/$1/server.crt)
  if [[ $? -ne 0 ]]
  then
    echo "Failed to create secret, consider running with --override-tracing-certs or --skip-tracing-certs-creation: ${ERR}"
    exit 1
  fi
  echo "secret/$1-tls created"
}

# $1 - configmap name
# $2 - configmap namespace
create_root_ca_configmap(){
  if [[ ! -z $OVERRIDE_TRACING_CERTS ]] ; then
    ${K8SCLI_CMD} delete configmap $1 -n $2 --ignore-not-found
  fi

  ERR=$(${K8SCLI_CMD} create configmap $1 -n $2 --from-file=${TRACING_CERT_DIR}/ca.crt)
  if [[ $? -ne 0 ]]
  then
    echo "Failed to create configmap, consider running with --override-tracing-certs or --skip-tracing-certs-creation: ${ERR}"
    exit 1
  fi
  echo "configmap/$1 created"
}

verify_tracing_ca_cert(){
    if [[ ! -f "${TRACING_CERT_DIR}"/ca.key ||  ! -f "${TRACING_CERT_DIR}"/ca.crt ]]; then
      echo "root CA cert files was not found in ${TRACING_CERT_DIR}"
      exit 1
    fi
}

# $1 - server name
verify_tracing_server_tls_cert(){
    if [[ ! -f "${TRACING_CERT_DIR}"/$1/server.key || ! -f "${TRACING_CERT_DIR}"/$1/server.crt ]]; then
      echo "$1 cert files was not found in ${TRACING_CERT_DIR}"
      exit 1
    fi
}

install_tracing_certs(){
  if [[ ! -d "${TRACING_CERT_DIR}" ]]
  then
    echo "creating folder ${TRACING_CERT_DIR}"
    ERR=$(mkdir -p "${TRACING_CERT_DIR}")
    if [ $? -ne 0 ]
    then
      echo ${ERR}
      exit 1
    fi
  fi

  if [ "$(ls -A "$TRACING_CERT_DIR")" ]
  then
    verify_tracing_ca_cert
    verify_tracing_server_tls_cert portshift-agent
    verify_tracing_server_tls_cert apiclarity
    echo "using certificates from existing certs folder: ${TRACING_CERT_DIR}"
  else
      echo "generating certificates in folder ${TRACING_CERT_DIR}"
      generate_tracing_certs
  fi

  local NS_EXISTS=$(${K8SCLI_CMD} get ns --no-headers | grep portshift)
  if [[ -z "$NS_EXISTS" ]] ; then
    echo "creating portshift namespace"
    ${K8SCLI_CMD} create namespace portshift --save-config
  fi

  create_root_ca_configmap portshift-root-ca.crt portshift
  create_server_tls_secret portshift-agent portshift
  create_server_tls_secret apiclarity portshift
}

function install_portshift() {
  local RESPONSE


  if [[ ${SKIP_TRACING_CERTS_CREATION} != "TRUE" ]] ; then
    install_tracing_certs
  fi

  local PORTSHIFT_FILENAME="$DIR""/portshift_bundle_ag.yml"

  extract_file "######################################## PORTSHIFT #######################################################" "" "${PORTSHIFT_BUNDLE_FILENAME}" "$PORTSHIFT_FILENAME"

  echo "Installing Panoptica components"
  RESPONSE=$(${K8SCLI_CMD} apply -f "${PORTSHIFT_FILENAME}" 2>&1)
  if [[ $? -ne 0 ]]
  then
    echo "Failed to install Panoptica: $RESPONSE"
    rm "${PORTSHIFT_FILENAME}"
    exit 1
  fi


  if [ "$SKIP_READY_CHECK" != "TRUE" ] ; then
    # Wait for the controller to be ready
    echo "Waiting for the Panoptica controller to be ready"
    i=0
    until RESPONSE=$(${K8SCLI_CMD} rollout -n portshift status deployment/portshift-agent --timeout 1m 2>&1)
    do
      i=$(( $i + 1 ))
      if [[ $i -eq 10 ]]
      then
        echo "Panoptica controller couldn't start: $RESPONSE"
        echo "Please contact support."
        rm "${PORTSHIFT_FILENAME}"
        exit 1
      fi
    done
    echo "Panoptica controller is ready"
  fi
  echo "Finished installing Panoptica"
  rm "${PORTSHIFT_FILENAME}"
}



uninstall_portshift_bundle(){
  ${K8SCLI_CMD} get cm -n portshift portshift-uninstaller -o jsonpath='{.data.config}' > uninstall.sh && chmod +x uninstall.sh
  ./uninstall.sh
}

compare_version () {
	local ver1=( ${1//./ } )
	local ver2=( ${2//./ } )
	if [[ ${ver1[0]} > ${ver2[0]} ]]; then
		return 1
	elif [[ ${ver1[0]} < ${ver2[0]} ]]; then
		return 2
	else
		if [[ ${ver1[1]} > ${ver2[1]} ]]; then
			return 1
		elif [[ ${ver1[1]} < ${ver2[1]} ]]; then
			return 2
		else
		  return 0
		fi
	fi
}


function verifyK8sVersion() {
  local SERVER_VERSION=$(${K8SCLI_CMD} version | grep Server)
  local MINOR=$(echo $SERVER_VERSION | grep -Eo 'Minor:"[0-9]+' | grep -Eo '[0-9]+')
  local MAJOR=$(echo $SERVER_VERSION | grep -Eo 'Major:"[0-9]+' | grep -Eo '[0-9]+')
  if [[ $MINOR == "" || $MAJOR == ""  ]] ; then
    echo "Failed to get K8s version from cluster. Please verify that ${K8SCLI_CMD} is configured properly and that "${K8SCLI_CMD} version" returns the version of your K8s cluster."
    exit 1
  fi
  min_k8s_version="1.22"
  cluster_ver=$MAJOR.$MINOR
  compare_version $MAJOR.$MINOR $min_k8s_version
  ret=$?
  if [[ $ret == 2 ]] ; then
    echo "The installed K8s version ($cluster_ver) is not supported. Please upgrade to version $min_k8s_version or higher."
    exit 1
  fi
}

## End Common Code ##

#### Entry Points ####
## Single-Cluster Entry Point ##
install(){
  SHOULD_INSTALL_ISTIO=$(grep "DONE ISTIO INIT PART" "$PORTSHIFT_BUNDLE_FILENAME")
  if [[ "${SHOULD_INSTALL_ISTIO}" != "" ]] ; then
    install_istio_crds
    install_istio
  fi
  install_portshift

}
#### End Entry Points ####

while [[ "$1" != "" ]]; do
    case $1 in
        --override-tracing-certs )      OVERRIDE_TRACING_CERTS="TRUE"
                                        ;;
        --skip-tracing-certs-creation ) SKIP_TRACING_CERTS_CREATION="TRUE"
                                        ;;
        --kubeconfig )         shift
                               KUBECONFIG="$1"
                               ;;
        --uninstall )          UNINSTALL="TRUE"
                               ;;
        --skip-ready-check )   SKIP_READY_CHECK="TRUE"
                               ;;
        -h | --help )          print_usage
                               exit
                               ;;
    *) print_usage
                                  exit 1
  esac
    shift
done

if [[ "${KUBECONFIG}" != "" ]] ; then
    export KUBECONFIG="${KUBECONFIG}"
fi

if [ "$UNINSTALL" == "TRUE" ] ; then
  uninstall_portshift_bundle
else
  verifyK8sVersion
  validate_ip_masq_agent_config
  install
fi
