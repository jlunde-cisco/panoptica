#!/bin/bash

set -euo pipefail

CERT_DIR=''

SERVER_CONF="server.conf"
ROOT_CA_CONF="ca.conf"

#------------------------------------------------------------------------
# variables: root CA
ROOTCA_DAYS=3650 # 10 years
ROOTCA_KEYSZ=4096
ROOTCA_ORG="Cisco"
ROOTCA_CN="Root CA"
# Additional variables are defined in ca.conf target below.

#------------------------------------------------------------------------
# variables: server cert
SERVER_DAYS=730 # 2 years
SERVER_KEYSZ=4096
SERVER_ORG="Panoptica"
SERVER_KEY_FILE_NAME="server.key"
SERVER_CSR_FILE_NAME="server.csr"
SERVER_CRT_FILE_NAME="server.crt"
# Additional variables are defined in server.conf target below.

print_usage() {
  printf "Usage:
  required arguments:
  c - folder where certificates will be generated
 "
}

create_cert_dir() {
  RESPONSE=$(mkdir -p ${CERT_DIR} 2>&1)
  if [ $? -ne 0 ]
  then
    echo ${RESPONSE}
    exit 1
  fi

  cd ${CERT_DIR}
}

# $1 - server name
# $2 - server namespace
# $3 - server cn
# $4 - server org
# $5 - ca crt path
# $6 - ca key path
generate_server_tls_certs() {
  RESPONSE=$(mkdir -p $1 2>&1)
  if [ $? -ne 0 ]
  then
    echo ${RESPONSE}
    exit 1
  fi

  cd $1

  L=$(pwd | sed "s/\///1")

  ## server.conf:
  echo "[ req ]" > $SERVER_CONF
  echo "encrypt_key = no" >> $SERVER_CONF
  echo "prompt = no" >> $SERVER_CONF
  echo "utf8 = yes" >> $SERVER_CONF
  echo "default_md = sha256" >> $SERVER_CONF
  echo "default_bits = $SERVER_KEYSZ" >> $SERVER_CONF
  echo "req_extensions = req_ext" >> $SERVER_CONF
  echo "x509_extensions = req_ext" >> $SERVER_CONF
  echo "distinguished_name = req_dn" >> $SERVER_CONF
  echo "[ req_ext ]" >> $SERVER_CONF
  echo "keyUsage = digitalSignature, keyEncipherment" >> $SERVER_CONF
  echo "extendedKeyUsage = serverAuth" >> $SERVER_CONF
  echo "subjectAltName = DNS:$1, DNS:$1.$2, DNS:$1.$2.svc, DNS:$1.$2.svc.cluster.local" >> $SERVER_CONF
  echo "[ req_dn ]" >> $SERVER_CONF
  echo "O = $4" >> $SERVER_CONF
  echo "CN = $3" >> $SERVER_CONF
  echo "L = $L" >> $SERVER_CONF

  ## server.key:
  echo "generating $SERVER_KEY_FILE_NAME"
  openssl ecparam -name secp384r1 -genkey -noout -out $SERVER_KEY_FILE_NAME

  ## server.csr
  echo "generating $SERVER_CSR_FILE_NAME"
  openssl req -new -config $SERVER_CONF -key $SERVER_KEY_FILE_NAME -out $SERVER_CSR_FILE_NAME

  ##  server.crt:
  echo "generating $SERVER_CRT_FILE_NAME"
  openssl x509 -req \
  -days $SERVER_DAYS \
  -CA "$5" -CAkey "$6" \
  -set_serial 0x$(openssl rand -hex 10) \
  -extensions req_ext \
  -extfile $SERVER_CONF \
  -in $SERVER_CSR_FILE_NAME \
  -out $SERVER_CRT_FILE_NAME

  echo "done generating $1.$2 certificates"
  echo ""

  cd -
}

generate_certs() {
  ## ca.key.pem
  echo "generating ca.key"
  openssl ecparam -name secp384r1 -genkey -noout -out ca.key

  L=$(echo ${CERT_DIR} | sed "s/\///1")

  ## ca.conf:
  echo "[ req ]" > $ROOT_CA_CONF
  echo "encrypt_key = no" >> $ROOT_CA_CONF
  echo "prompt = no" >> $ROOT_CA_CONF
  echo "utf8 = yes" >> $ROOT_CA_CONF
  echo "default_md = sha256" >> $ROOT_CA_CONF
  echo "default_bits = $ROOTCA_KEYSZ" >> $ROOT_CA_CONF
  echo "req_extensions = req_ext" >> $ROOT_CA_CONF
  echo "x509_extensions = req_ext" >> $ROOT_CA_CONF
  echo "distinguished_name = req_dn" >> $ROOT_CA_CONF
  echo "[ req_ext ]" >> $ROOT_CA_CONF
  echo "subjectKeyIdentifier = hash" >> $ROOT_CA_CONF
  echo "basicConstraints = critical, CA:true" >> $ROOT_CA_CONF
  echo "keyUsage = critical, digitalSignature, nonRepudiation, keyEncipherment, keyCertSign" >> $ROOT_CA_CONF
  echo "[ req_dn ]" >> $ROOT_CA_CONF
  echo "O = $ROOTCA_ORG" >> $ROOT_CA_CONF
  echo "CN = $ROOTCA_CN" >> $ROOT_CA_CONF

  ## ca.csr
  echo "generating ca.csr"
  openssl req -new -key ca.key -config ca.conf -out ca.csr

  ## ca.crt
  echo "generating ca.crt"
  openssl x509 -req -days $ROOTCA_DAYS -signkey ca.key \
  -extensions req_ext -extfile ca.conf \
  -in ca.csr -out ca.crt

  generate_server_tls_certs portshift-agent portshift portshift-agent Cisco "$(pwd)/ca.crt" "$(pwd)/ca.key"
  generate_server_tls_certs apiclarity portshift apiclarity Cisco "$(pwd)/ca.crt" "$(pwd)/ca.key"

  echo "done generating certificates"
  echo ""
}

main() {
  create_cert_dir
  generate_certs
}

while getopts 'c:' flag; do
  case "${flag}" in
    c) CERT_DIR="${OPTARG}" ;;
    *) print_usage
        exit 1 ;;
  esac
done
main
